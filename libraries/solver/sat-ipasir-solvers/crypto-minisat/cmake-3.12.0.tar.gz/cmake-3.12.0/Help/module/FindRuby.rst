.. cmake-module:: ../../Modules/FindRuby.cmake
